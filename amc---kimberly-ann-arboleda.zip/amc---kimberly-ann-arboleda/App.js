import { SafeAreaView, StyleSheet, ScrollView, View, ImageBackground} from 'react-native';

import Header from './components/Header';
import Information from './components/Information';
import Appointment from './components/Appointment';
import AboutMe from './components/AboutMe';
import Services from './components/Services';
import Gallery from './components/Gallery';
import Memories from './components/Memories';
import Testimonial from './components/Testimonial';
import Footer from './components/Footer';

export default function App() {
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView
        contentContainerStyle={{
            flexGrow: 1,
            justifyContent: 'space-between',
        }}
      >
        <ImageBackground source={require('./assets/BG.jpg')} resizeMode={'repeat'} style={{height: '100%'}}>
          <Header />
          <View style={{backgroundColor:'#242526',marginBottom: 10}}>
            <Information />
          </View>
          <AboutMe />
          <Appointment />
          <Services />
          <Gallery />
          <Memories />
          <Testimonial />
          <Footer />
        </ImageBackground>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexGrow: 1,
    justifyContent: 'center',
    backgroundColor: '#18191a',
    height: "100%"
  },
});
