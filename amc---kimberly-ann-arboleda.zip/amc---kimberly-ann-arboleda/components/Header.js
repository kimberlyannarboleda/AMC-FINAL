import { Text, View, StyleSheet, Image, ImageBackground } from 'react-native';


export default function Header() {
  return (
    <ImageBackground style={styles.container} source={require('../assets/IMG_4169.jpeg')} resizeMode="cover">
      <View style={styles.table}>
        <Image style={styles.logo} source={require('../assets/IMG_4168.jpg')} />
        <Text style={styles.name}>
          Kimberly Ann Arboleda
        </Text>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  container: {
    resizeMode: 'cover',
    flexDirection: 'row',
    position: 'relative',
    height: 100,
    zIndex:99
  },
  table: {
    position: 'absolute',
    borderRadius: '100%',
    marginTop: 50,
    marginLeft: 10,
    flex: 1,
    flexDirection: 'row'
  },
  name: {
    fontSize: 14,
    display:'block',
    alignSelf:'center',
    marginLeft: 10,
    fontWeight: 'bold',
    color: 'white',
    marginTop: -10,
    textShadow: "0px  0px  10px  black",
    textShadowColor: 'rgba(0, 0, 0, 0.75)',
    textShadowOffset: {width: -1, height: 1},
    textShadowRadius: 10
  },
  logo: {
    height: 80,
    width: 80,
    borderRadius:'100%',
    borderWidth: 5,
    borderColor: '#242526'
  }
});
