import { Text, View, StyleSheet, Image, FlatList, useWindowDimensions } from 'react-native';
import { useState, useRef } from 'react';

export default function Gallery() {
  const images = [
    { id: '1', image: require('../assets/1A.jpg') },
    { id: '2', image: require('../assets/1B.jpg') },
    { id: '3', image: require('../assets/1C.jpg') },
    { id: '4', image: require('../assets/1D.jpg') },
    { id: '5', image: require('../assets/1E.jpg') },
    // Add more images as needed
  ];
  const onViewRef = useRef(({ viewableItems }) => {
    if (viewableItems.length > 0) {
      setActiveIndex(viewableItems[0].index);
    }
  });
  const { width } = useWindowDimensions();
  const viewConfigRef = useRef({ viewAreaCoveragePercentThreshold: 50 });
  const [activeIndex, setActiveIndex] = useState(0);

  return (
    <View style={styles.container}>
      <Text style={styles.header}>
        Gallery
      </Text>
      <View style={styles.row}>
        <FlatList
          data={images}
          renderItem={({ item }) => (
            <Image source={item.image} style={{ width: 250, height: 170, borderRadius: 15, marginRight: 10 }} />
          )}
          horizontal
          pagingEnabled
          showsHorizontalScrollIndicator={false}
          onScrollToIndexFailed={info => {
            console.log("Scroll to index failed:", info);
          }}
          onViewableItemsChanged={onViewRef.current}
          viewabilityConfig={viewConfigRef.current}
          keyExtractor={item => item.id}
          style={{width:"100%"}}
        />
        <View style={styles.pagination}>
          {images.map((_, index) => (
            <View
              key={index}
              style={[styles.dot, index === activeIndex ? styles.activeDot : null]}
            />
          ))}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  pagination: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 10,
    marginBottom: -5
  },
  dot: {
    height: 10,
    width: 10,
    borderRadius: 5,
    backgroundColor: 'gray',
    margin: 8,
  },
  activeDot: {
    backgroundColor: 'white',
  },
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor:'#242526',
    width: '90%',
    margin: 'auto',
    marginTop: 10,
    borderRadius: 10
  },
  header: {
    width:'100%',
    color:'white',
    fontSize: 15,
    fontWeight: 'bold',
    padding:10,
    marginBottom: 10
  },
  row: {
    flex: 1,
    flexDirection: 'column',
    flexWrap:'wrap',
    justifyContent:'space-between',
    width:'100%',
    marginTop: -10,
    paddingHorizontal: 10,
    marginBottom: 10
  },
});
