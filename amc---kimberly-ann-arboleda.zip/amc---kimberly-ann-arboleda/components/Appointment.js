import { Text, View, StyleSheet, TextInput, TouchableOpacity, Alert } from 'react-native';
import { useState } from 'react';
export default function Appointment() {
  const [date, setDate] = useState('August 16, 2001');
  const [time, setTime] = useState('04:00:AM');
  const onAppoint = () => {
      Alert.alert("Congratulations!", "You have been set an appointment", [{ text: 'OK' }]);
  };
  return (
    <View style={styles.container}>
      <Text style={styles.header}>
        Make an Appointment
      </Text>
      <View style={styles.row}>
        <Text style={styles.text}>Date</Text>
        <TextInput style={styles.input} onChangeText={newText => setDate(newText)} defaultValue={date}/>
      </View>
      <View style={styles.row}>
        <Text style={styles.text}>Time</Text>
        <TextInput style={styles.input} onChangeText={newText => setTime(newText)} defaultValue={time}/>
      </View>
      <TouchableOpacity
        style={{backgroundColor:'#3a3b3c',paddingHorizontal: 12,paddingVertical: 10,marginBottom: 10,borderRadius: 10}}
        onPress={onAppoint}
      >
        <Text style={{fontWeight:'bold', fontSize: 12,color:"white"}}>Book now!</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor:'#242526',
    width: '90%',
    margin: 'auto',
    marginTop: 10,
    borderRadius: 10
  },
  header: {
    width:'100%',
    color:'white',
    fontSize: 15,
    fontWeight: 'bold',
    padding:10,
  },
  row: {
    flex: 1,
    flexDirection: 'column',
    flexWrap:'wrap',
    justifyContent:'space-between',
    width:'100%',
    paddingHorizontal: 10,
    marginBottom: 10
  },
  input: {
    backgroundColor:'white',
    paddingVertical: 8,
    paddingHorizontal: 6,
    fontSize: 12,
    width: '100%'
  },
  text: {
    fontSize: 12,
    fontWeight: 'bold',
    marginBottom: 5,
    color:'white',
    width:'100%'
  }
});
