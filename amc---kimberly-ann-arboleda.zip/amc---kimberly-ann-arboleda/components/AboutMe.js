import { Text, View, StyleSheet, TextInput } from 'react-native';
export default function AboutMe() {
  return (
    <View style={styles.container}>
      <Text style={styles.header}>
        About me
      </Text>
      <View style={styles.row}>
        <Text style={{color:'white',fontSize: 11, textAlign:'justify', width:'100%'}}>Hello, I'm Kimberly Ann Arboleda, a skilled Graphic Designer with a passion for solving complex problems and optimizing system. Im currently a 3rd year student in Global Reciprocal Colleges. , I thrive on tackling challenges head-on and delivering innovative solutions that exceed expectations! So why wait you can hire me.</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor:'#242526',
    width: '90%',
    margin: 'auto',
    marginTop: 10,
    borderRadius: 10
  },
  header: {
    width:'100%',
    color:'white',
    fontSize: 15,
    fontWeight: 'bold',
    padding:10,
  },
  row: {
    flex: 1,
    flexDirection: 'column',
    flexWrap:'wrap',
    justifyContent:'space-between',
    width:'100%',
    paddingHorizontal: 10,
    marginBottom: 10
  },
});
