import { Text, View, StyleSheet, TextInput } from 'react-native';
export default function Services() {
  return (
    <View style={styles.container}>
      <Text style={styles.header}>
        Services
      </Text>
      <View style={styles.row}>
        <Text style={{color:'white',fontSize: 13, textAlign:'justify',fontWeight: 'bold',marginBottom: 10,width:'100%'}}>Graphic Design</Text>
        <Text style={{color:'white',fontSize: 11, textAlign:'justify',width:'100%'}}>
          I'm Kimberly Ann Arboleda, your versatile design assistant, ready to inspire and assist with creative projects. Think of me as your go-to template for ideas, research, and writing. Just like a great design, I blend functionality with creativity to meet your needs. Let's create something amazing together!
        </Text>
        <View style={{backgroundColor:'#676a6b',height: 1,marginVertical: 10}}></View>
        <Text style={{color:'white',fontSize: 13, textAlign:'justify',fontWeight: 'bold',marginBottom: 10,width:'100%'}}>Volleyball</Text>
        <Text style={{color:'white',fontSize: 11, textAlign:'justify',width:'100%'}}>
          Hey there! I'm Kimberly Ann Arboleda, a dedicated volleyball player with a passion for the game and a drive for excellence. My journey on the court has been fueled by relentless training, teamwork, and a never-give-up attitude. Every spike, block, and dive represents my commitment to pushing limits and achieving goals. Let's team up and reach new heights together!
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor:'#242526',
    width: '90%',
    margin: 'auto',
    marginTop: 10,
    borderRadius: 10
  },
  header: {
    width:'100%',
    color:'white',
    fontSize: 15,
    fontWeight: 'bold',
    padding:10,
  },
  row: {
    flex: 1,
    flexDirection: 'column',
    flexWrap:'wrap',
    justifyContent:'space-between',
    width:'100%',
    paddingHorizontal: 10,
    marginBottom: 10
  },
});
