import { Text, View, StyleSheet, TouchableOpacity, Linking } from 'react-native';
import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import { FontAwesome } from '@expo/vector-icons';
import { Entypo } from '@expo/vector-icons';

export default function Information() {
  return (
    <View style={styles.container}>
      <View style={styles.row}>
        <View style={styles.rowFlex}>
          <Text>
            <MaterialCommunityIcons name="gmail" size={15} color="#a2a5ab" />
          </Text>
          <Text style={styles.text}>
            kimberlyannarboleda16@gmail.com
          </Text>
        </View>
      </View>
      <View style={styles.row}>
        <View style={styles.rowFlex}>
          <Text>
            <MaterialCommunityIcons name="phone" size={15} color="#a2a5ab" />
          </Text>
          <Text style={styles.text}>
            +63 977 022 5299
          </Text>
        </View>
      </View>
      <View style={styles.row}>
        <View style={styles.rowFlex}>
          <Text>
            <FontAwesome name="birthday-cake" size={15} color="#a2a5ab" />
          </Text>
          <Text style={styles.text}>
            August 16, 2001
          </Text>
        </View>
      </View>
      <View style={styles.row}>
        <View style={styles.rowFlex}>
          <Text>
            <Entypo name="location" size={15} color="#a2a5ab" />
          </Text>
          <Text style={styles.text}>
            Quezon City, Philippines
          </Text>
        </View>
      </View>
      <View style={styles.row2}>
        <View style={styles.rowFlex2}>
          <TouchableOpacity
            onPress={() => {
              Linking.openURL("https://www.facebook.com/kimberlyann.arboleda");
            }}
            style={{borderBottomWidth: 1, borderColor:'#a2a5ab'}}
          >
            <Text>
              <Entypo name="facebook" size={15} color="#a2a5ab" />&nbsp;
              <Text style={styles.text2}>
                Facebook
              </Text>
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => {
              Linking.openURL("https://www.instagram.com/itzygirlcallie");
            }}
            style={{borderBottomWidth: 1, borderColor:'#a2a5ab'}}
          >
            <Text>
              <Entypo name="instagram" size={15} color="#a2a5ab"/>&nbsp;
              <Text style={styles.text2}>
                Instagram
              </Text>
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginLeft: 100,
    paddingVertical: 10,
  },
  row: {
    width:'100%',
  },
  row2: {
    width:'60%',
  },
  rowFlex: {
    flex: 1,
    flexDirection:'row',
    marginTop: 2.5,
    marginBottom: 2.5
  },
  rowFlex2: {
    flex: 1,
    flexDirection:'row',
    marginTop: 2.5,
    marginBottom: 2.5,
    justifyContent:'space-between'
  },
  text: {
    marginLeft:10,
    marginTop: 2,
    fontSize: 10,
    color: "#a2a5ab"
  },
  text2: {
    marginTop: -2,
    fontSize: 10,
    color: "#a2a5ab",
    width:'auto'
  }
});
