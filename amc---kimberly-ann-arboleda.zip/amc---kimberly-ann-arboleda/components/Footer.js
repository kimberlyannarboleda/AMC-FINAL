import { Text, View, StyleSheet, TextInput } from 'react-native';
export default function Footer() {
  return (
    <View style={styles.container}>
      <View style={styles.row}>
        <Text style={{color:'white',fontSize: 11, textAlign:'justify', width:'100%'}}>&copy; 2024 - Kimberly Ann Arboleda</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor:'#242526',
    width: '90%',
    margin: 'auto',
    marginTop: 10,
    borderRadius: 10,
    
    marginBottom: 20,
    
  },
  row: {
    paddingVertical: 10
  },
});
